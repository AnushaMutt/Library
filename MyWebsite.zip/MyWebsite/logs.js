
function validateform(){
var name=document.myform.name.value;
var password=document.myform.password.value;

if(name==null || name==""){
alert("enter user name")
return false;
}
if(password.length<6){
alert("password has to be atleast 6 ")
return false;
}

var e=document.getElementById("sel");
var option = e.options[e.selectedIndex].value;

if(option==1)
{
window.open("homeA.html");
}else if(option==2){
window.open("homeS.html");

}else{
alert("please select")
}

}



$(function(){


$("#sel").css("background-color","#B0E0E6");

$("#form").animate(
{

"font-size":"25px"
});


$("input").css("background-color","#B0E0E6");

$(".sel").css("background-color","#B0E0E6");

$("#foot").slideDown(2000);
$("#footer").slideUp(1000);
$("#footer").slideDown(1000);


});