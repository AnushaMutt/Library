$(function(){

$("input").css("background-color","#B0E0E6");

$("#sel").css("background-color","#B0E0E6");

$(".sel").css("background-color","#B0E0E6");


$(".text").css("background-color","#B0E0E6");



$("#footer").slideUp(1000);
$("#footer").slideDown(1000);

});