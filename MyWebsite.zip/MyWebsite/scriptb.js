function validateform()
            {

var name=document.myform.name.value;


if(name==null || name==""){
alert("enter user name")
return false;
}

 var e = document.getElementById("op");
                  var optionSelIndex = e.options[e.selectedIndex].value;
            
                
            if (optionSelIndex == 0) {
                alert("Please select type of the book");
            }
               
 }
 



$(function(){

$("input").css("background-color","#B0E0E6");

$(".sel").css("background-color","#B0E0E6");

$("#form").animate(
{

"font-size":"20px"
});


$("#footer").slideUp(1000);
$("#footer").slideDown(1000);


});